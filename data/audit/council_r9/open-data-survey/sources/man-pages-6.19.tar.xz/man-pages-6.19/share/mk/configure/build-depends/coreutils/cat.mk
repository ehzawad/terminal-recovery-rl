# Copyright, the authors of the Linux man-pages project
# SPDX-License-Identifier: LGPL-3.0-only WITH LGPL-3.0-linking-exception


ifndef MAKEFILE_CONFIGURE_BUILD_DEPENDS_COREUTILS_CAT_INCLUDED
MAKEFILE_CONFIGURE_BUILD_DEPENDS_COREUTILS_CAT_INCLUDED ::= 1


ifndef CAT
CAT ::= cat
endif


endif  # include guard
